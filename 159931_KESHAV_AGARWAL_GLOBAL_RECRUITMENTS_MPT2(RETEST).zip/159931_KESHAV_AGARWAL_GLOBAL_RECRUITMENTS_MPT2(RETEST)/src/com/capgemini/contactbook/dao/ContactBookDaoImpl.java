package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.util.ConnectionProvider;
import com.igate.contactbook.bean.EnquiryBean;
public class ContactBookDaoImpl implements ContactBookDao{
	private Connection conn=ConnectionProvider.getDBConnection();
	private static final Logger logger=Logger.getLogger(ContactBookService.class);

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException, SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt=conn.prepareStatement("INSERT INTO enquiry1(enqryId,firstName,lastName,contactNo,domain,city) VALUES(enquiries.nextval,?,?,?,?,?)");
			pstmt.setString(1,enqry.getfName());
			pstmt.setString(2,enqry.getlName());
			pstmt.setString(3,enqry.getContactNo());
			pstmt.setString(4,enqry.getpDomain());
			pstmt.setString(5,enqry.getpLocation());
			pstmt.executeUpdate();
			PreparedStatement pstmt2=conn.prepareStatement("SELECT max(enqryId) from enquiry");
			ResultSet rs=pstmt2.executeQuery();
			rs.next();
			int enqryId=rs.getInt(1);
			conn.commit();
			enqry.setEnqryId(enqryId);
			return enqryId;
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
			logger.error(e.getCause()+" "+e.getErrorCode()+" "+e.getMessage());
			throw new ContactBookException();
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public EnquiryBean getEnquiry(int EnquiryID) throws ContactBookException {
		try {
			PreparedStatement pstmt1=conn.prepareStatement("SELECT *  FROM enquiry where enqryId="+EnquiryID);
			ResultSet rs=pstmt1.executeQuery();
			if(rs.next()) {
				String firstName=rs.getString("firstName");
				String lastName=rs.getString("lastName");
				String contactNo=rs.getString("contactNo");
				String domain=rs.getString("domain");
				String city=rs.getString("city");
				EnquiryBean enquiryBean=new EnquiryBean(EnquiryID,firstName, lastName, contactNo, city, domain);
				return enquiryBean;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getCause()+" "+e.getErrorCode()+" "+e.getMessage());
			throw new ContactBookException();
		}
		return null;
	}

}
