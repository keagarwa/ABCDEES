package com.capgemini.contactbook.service.test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.exceptions.ContactBookException;
import com.capgemini.contactbook.exceptions.ContactBookServiceDetailsNotFound;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;
import com.igate.contactbook.bean.EnquiryBean;
public class EnquiryBeanServiceTest {
	private static ContactBookService contactService;
	private static ContactBookDao mockContactDao;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockContactDao= EasyMock.mock(ContactBookDao.class);
		contactService = new ContactBookServiceImpl(mockContactDao);
	}
	public void setUpTestData() throws ContactBookServiceDetailsNotFound, ContactBookException {	
		EnquiryBean enquiryBean=new EnquiryBean(1003,"keshav","agarwal","9693866489","pune","hhh");
		try {
			EasyMock.expect(mockContactDao.getEnquiry(1003)).andReturn(enquiryBean);
		} catch (Exception e4) {
			e4.printStackTrace();
		}
	}
	@Test
	public void testGetContactBookDetailsForValidEnquiryId() throws ContactBookException{
		EnquiryBean expectedEnquiryBean=new EnquiryBean(1003,"keshav","agarwal","9693866489","pune","hhh");
		EnquiryBean actualEnquiryBean = contactService.getEnquiryDetails(1003);

		try {
			EasyMock.verify(mockContactDao.getEnquiry(1003));
		} catch (Exception e) {
			e.printStackTrace();
		}
		assertEquals(expectedEnquiryBean, actualEnquiryBean);
	}
	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public void testAcceptContactBookDetailsForValidData() throws ContactBookException, SQLException {
		int expectedEnquiryId = 1003;
		int actualEnquiryId = contactService.addEnquiry(new EnquiryBean("keshav","agarwal","9693866489","pune","hhh"));
		assertEquals(expectedEnquiryId, actualEnquiryId);
	}

	@Test(expected = ContactBookServiceDetailsNotFound.class)
	public void testDetailsForInvalidEnquiryId()
			throws ContactBookServiceDetailsNotFound, ContactBookException{
		try {
			contactService.getEnquiryDetails(1234);
		} catch (Exception e1) {
			e1.printStackTrace();
		}

		try {
			EasyMock.verify(mockContactDao.getEnquiry(1234));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@After
	public void tearDownTestData() {

	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockContactDao=null;
		contactService=null;
	}
}
